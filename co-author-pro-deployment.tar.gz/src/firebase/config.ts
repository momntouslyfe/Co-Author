export const firebaseConfig = {
  "projectId": "studio-6914152784-d6441",
  "appId": "1:666100698197:web:f962b2d7d83a52eb8218dc",
  "apiKey": "AIzaSyCfqpqhZfrUiF9uR2QaUi5_moBNnjcCwQA",
  "authDomain": "studio-6914152784-d6441.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "666100698197"
};
